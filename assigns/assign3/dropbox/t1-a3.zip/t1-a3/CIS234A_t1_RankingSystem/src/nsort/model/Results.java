package nsort.model;

public class Results 
{

}
