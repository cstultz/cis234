package nsort.model;

public class Role {

}
