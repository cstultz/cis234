package nsort.model;

public class LoginState {

}
