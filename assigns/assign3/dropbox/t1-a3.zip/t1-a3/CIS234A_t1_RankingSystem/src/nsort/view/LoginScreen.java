package nsort.view;

import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

@SuppressWarnings("serial")
public class LoginScreen extends JFrame {

	private JPanel contentPane;
	private JTextField enterUsernameTextBox;
	private JPasswordField passwordField;
	private static LoginScreen loginScreen;
	private static AdminTestSetupScreen adminTestSetupScreen;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginScreen = new LoginScreen();
					loginScreen.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginScreen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 330, 227);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel loginPanel = new JPanel();
		loginPanel.setBounds(10, 11, 294, 167);
		contentPane.add(loginPanel);
		
        // set border for the panel
		loginPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Login Panel"));
		loginPanel.setLayout(null);
		
		JLabel lblEnterUsername = new JLabel("Enter username:");
		lblEnterUsername.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblEnterUsername.setBounds(10, 35, 90, 14);
		loginPanel.add(lblEnterUsername);
		
		JLabel lblEnterPassword = new JLabel("Enter password:");
		lblEnterPassword.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblEnterPassword.setBounds(10, 90, 90, 14);
		loginPanel.add(lblEnterPassword);
		
		enterUsernameTextBox = new JTextField();
		enterUsernameTextBox.setBounds(110, 32, 172, 20);
		loginPanel.add(enterUsernameTextBox);
		enterUsernameTextBox.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				//login logic to go here eventually
				adminTestSetupScreen = new AdminTestSetupScreen();
				loginScreen.setVisible(false);
				adminTestSetupScreen.setVisible(true);
			}
		});
		btnNewButton.setBounds(102, 133, 89, 23);
		loginPanel.add(btnNewButton);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(110, 87, 172, 20);
		loginPanel.add(passwordField);
	}
}
