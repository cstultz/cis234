package nsort.model;

/**
 * The SqlUser234A_t1 class connects to the 234a_t1 MS SQL database.
 * 
 * @author (Chris Stultz) 
 * @version (4/17/2015)
 */
import java.sql.*;
import java.util.ArrayList;

public class SqlUser_234a_t1 {

	private Connection conn = null;
	private String url = "jdbc:sqlserver://cisdbss.pcc.edu;"
			           + " databaseName=234a_t1; "
			           + "user=234a_t1; "
			           + "password=1t_a432@#";

	/**
     * Constructor for the class.
     */
    public SqlUser_234a_t1()
    {
		try
		{
	    	if (connect(url))
	    	{
	    		//connected; do nothing.
	    	}
	    	else
	    	{
	    		System.err.println("Unable to connect to the 234a_t1 database");
	    	}
		}
		catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
    }
    
    /**
     * connect to the database
     * 
     * @param url for database connection
     * @return true if the connection was successful; false if not successful
     */
    public boolean connect (String url)
    {
    	try
    	{
    		conn = DriverManager.getConnection(url);
    	}
    	catch (Exception e)
    	{
    		return false;
    	}

    	if(conn != null)
		{
			return true;
		}
		else return false;
    }
    
    /**
     * pull the existing words from the Item table in the database
     * 
     * @return list of existing words from the Item table in the database
     */
    public ArrayList<String> pullExistingItems()
    {
    	String query = "select * from [234a_t1].dbo.Item";
    	ArrayList<String> description = new ArrayList<String>();
    	Statement stmt = null;
    	
    	try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next())
			{
				String input = rs.getString("description");
				description.add(input);
			}
		}
		catch (SQLException e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
    	return description;
    }
    
    /**
     * pull the users from the User table in the database
     * 
     * @return the list of users from the User table in the database
     */
    public ArrayList<User> pullUsers()
    {
    	String query = "select * from [234a_t1].dbo.[User]";
    	ArrayList<User> users = new ArrayList<>();
    	Statement stmt = null;
    	
    	try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next())
			{
				String firstName= rs.getString("firstName");
				String lastName = rs.getString("lastName");
				String eMail = rs.getString("eMail");
				String username = rs.getString("username");
				String password = rs.getString("password");
				User user = new User(firstName, lastName, eMail, username, password);
				users.add(user);
			}
		}
		catch (SQLException e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
    	return users;
    }
}