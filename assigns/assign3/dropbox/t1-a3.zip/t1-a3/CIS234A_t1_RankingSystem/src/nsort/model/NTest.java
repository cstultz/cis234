/**
 * 
 */
package nsort.model;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author john_loranger
 *
 */
public class NTest {
	
	private ArrayList<Question> questions = new ArrayList<Question>();	
	public NTest(){}
	
	 
	public Iterator<Question> iterator() {
		return questions.iterator();
	}; 
	
	/**
	 * @return the number of questions
	 */
	public int numberOfQuestions() {
		return questions.size();
	}

	/**
	 * @param questions the questions to set
	 */
	public void addQuestion(Question question) {
		questions.add(question);
	}
}

/*
window.onload=init();

 var questions;
 var currentQuestion;

 function loadQuestions() {

     questions = [
         {   itemLeft: "bananas",
             itemRight: "apples",
             answer: "3"
         },
         {
             itemLeft: "oranges",
             itemRight: "cherries",
             answer: "3"
         }];
     currentQuestion = 0;
 }

 function init() {
     loadQuestions();
     if ( currentQuestion < questions.length ) {
         displayQuestion( questions[currentQuestion] );
     } else {
         alert("No Questions to Display.");
     }

 }
//todo - need to get itemLeft,right to work with this...
 function displayQuestion(question) {
     document.getElementById("leftDisplay").innerHTML=question.itemLeft;
     document.getElementById("rightDisplay").innerHTML=question.itemRight;
     setRadioChoice( question.answer );
     setButtonEnableProperties();
 }

 function setRadioChoice( answer ) {
     var i;
     for ( i=0; i< document.radioform.choice.length; i++ ) {
         document.radioform.choice[i].checked = ( i == answer );
     }
 }

function getRadioChoice() {
    var i;
    for ( i=0; i< document.radioform.choice.length; i++ ) {
        if (document.radioform.choice[i].checked == true) {
            return i;
        }
    }
    return 3; // 3 indicates question unanswered.
}

function setButtonEnableProperties() {
    document.getElementById("previousButton").disabled = isCurrentQuestionFirstQuestion();
    document.getElementById("nextButton").disabled = isCurrentQuestionLastQuestion()
}

function isCurrentQuestionFirstQuestion() {
    return ( currentQuestion == 0 );
}
function isCurrentQuestionLastQuestion() {
    return ( currentQuestion == questions.length-1 );
}

 function saveQuestion( question ){
      question.answer = getRadioChoice();
 }

 function next() {
     saveQuestion( questions[currentQuestion]);
     currentQuestion++;
     displayQuestion( questions[currentQuestion]);
 }

 function previous() {
     saveQuestion( questions[currentQuestion]);
     currentQuestion--;
     displayQuestion( questions[currentQuestion]);
 }
*/