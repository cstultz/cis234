package nsort.test;

import static org.junit.Assert.*;
import nsort.model.Item;
import nsort.model.ItemList;

import org.junit.Test;

public class ItemList_UT {

	@Test
	public void testFail() {
		//fail();
	}

	@Test
	public void objectConstructed() 
	{
		@SuppressWarnings("unused")
		Item item = new Item();
	}

	@Test
	public void ObjectCreatedAndAddWordToTest() {
		ItemList itemList = new ItemList("Cheeses");
		Item item = new Item();
		item.setValue("Turkey");
		itemList.addItem(item);
		assertEquals("Cheeses", itemList.getName());
	}
}
