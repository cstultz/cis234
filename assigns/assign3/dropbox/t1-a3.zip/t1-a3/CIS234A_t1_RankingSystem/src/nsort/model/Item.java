package nsort.model;
/**
 * Item is an nsort.model component.  An Item is an 'item' that a nsort.test taker 
 * will compare to another item.
 * 
 * @author (John.Loranger) 
 * @version (4/21/2015)
 */
public class Item {
	
	private String value;
	
	public Item() 
	{
		setValue("");
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
