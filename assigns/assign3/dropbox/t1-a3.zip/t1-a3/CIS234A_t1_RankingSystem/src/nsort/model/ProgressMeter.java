package nsort.model;

public class ProgressMeter {

}
