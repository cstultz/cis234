/**
 * 
 */
package nsort.test;


import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;



import nsort.model.Answer;
import nsort.model.Item;
import nsort.model.Question;
import nsort.model.NTest;

import org.junit.Test;

/**
 * @author john_loranger
 *
 */
@SuppressWarnings("unused")
public class NTest_UT {

	// creates an array of zero questions
	private NTest getNTestQtyZero(){
		return new NTest();
	}

	// creates an array of 1 question
	private NTest getNTestQtyOne(){

		NTest nTest = new NTest();

		Question question =new Question();
		
		Item itemBananas 	= new Item();
		Item itemApples 	= new Item();
		
		itemBananas.setValue("Bananas");
		itemApples.setValue("Apples");
			
		question.setItemLeft(itemBananas);
		question.setItemRight(itemApples);

		nTest.addQuestion(question);
		
		return nTest;
	}
	
	// creates an array of 2 questions
	private NTest getNTestQtyTwo(){

		NTest nTest = new NTest();

		Question question1 =new Question();
		Question question2 =new Question();
		
		Item itemBananas 	= new Item();
		Item itemApples 	= new Item();
		Item itemOranges 	= new Item();
		Item itemCherries 	= new Item();
		
		itemBananas.setValue("Bananas");
		itemApples.setValue("Apples");
		itemOranges.setValue("Oranges");
		itemCherries.setValue("Cherries");
			
		question1.setItemLeft(itemBananas);
		question1.setItemRight(itemApples);

		question2.setItemLeft(itemOranges);
		question2.setItemRight(itemCherries);
		
		nTest.addQuestion(question1);
		nTest.addQuestion(question2);
		
		return nTest;
	}

	@Test
	public void getNTestInstantiation1() {
		NTest nTest = new NTest();
		assertNotNull("Instantiation failed.", nTest);
	}

	
	@Test
	public void testTestGetQuestionsWithNoQuestions() {
		NTest nTest = new NTest();
		assertEquals("number of questions input does not match numberOfQuestions call",0, 
				nTest.numberOfQuestions() );
	}


	@Test
	public void testWithQuestionsQtyZero() {
		NTest nTest = getNTestQtyZero();
		assertEquals("number of questions input does not match numberOfQuestions call",0, 
				nTest.numberOfQuestions() );
	}

	@Test
	public void testWithQuestionsQtyOne() {
		NTest nTest = getNTestQtyOne();
		assertEquals("number of questions input does not match numberOfQuestions call",1, 
				nTest.numberOfQuestions());
	}

	@Test
	public void testWithQuestionsQtyTwo() {
		NTest nTest = getNTestQtyTwo();
		assertEquals("number of questions input does not match numberOfQuestions call",2,   
				nTest.numberOfQuestions() );
	}

	@Test
	public void testNextWithQtyZero() {
		NTest nTest = getNTestQtyZero();
		Iterator<Question> itr = nTest.iterator();
		
		assertFalse("hasNext did not return expected value of false when called on new zero element question list", itr.hasNext() );
	}

	@Test
	public void testNextWithQtyOne() {
		NTest nTest = getNTestQtyOne();

		Iterator<Question> itr = nTest.iterator();
		
		Question question = itr.next();
			
		assertNotNull("next() did return null when called with new qty 1 NTest", question );
		
		assertFalse("hasNext did not return expected value of false after pulling first element from question list", itr.hasNext() );

	}

	@Test
	public void testNextWithQtyTwo() {
		NTest nTest = getNTestQtyTwo();

		Iterator<Question> itr = nTest.iterator();
		
		Question question1 = itr.next();
			
		assertNotNull("next() did return null when called with new qty 1 NTest", question1 );

		Question question2 = itr.next();

		assertNotNull("second next() did return null when called with new qty 1 NTest", question2 );
	
	}

	@Test
	public void testQuestionDataWithQtyOne() {
		NTest nTest = getNTestQtyOne();

		Iterator<Question> itr = nTest.iterator();
		
		Question question1 = itr.next();
		
		assertEquals("Question.getItemLeft is not expected value of Bananas","Bananas", question1.getItemLeft().getValue() );
		assertEquals("Question.getItemRight is not expected value of Apples","Apples", question1.getItemRight().getValue() );
		assertEquals("Question.getAnswer is not expected value of UNANSWERED", Answer.Value.UNANSWERED, question1.getAnswer().getValue());
	}

	@Test
	public void testQuestionDataWithQtyTwo() {
		NTest nTest = getNTestQtyTwo();

		Iterator<Question> itr = nTest.iterator();
		
		itr.next();
		Question question2 = itr.next();
			
		assertEquals("Question.getItemLeft is not expected value of Oranges","Oranges",    question2.getItemLeft().getValue() );
		assertEquals("Question.getItemRight is not expected value of Cherries","Cherries", question2.getItemRight().getValue() );
		assertEquals("Question.getAnswer is not expected value of UNANSWERED", Answer.Value.UNANSWERED, question2.getAnswer().getValue());
		
	}
}