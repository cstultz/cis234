package nsort.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import nsort.model.Item;
import nsort.model.SqlUser_234a_t1;
import nsort.model.User;

import org.junit.Test;

@SuppressWarnings("unused")
public class SqlUser_234a_t1_UT {

	@Test
	public void testFail() {
		//fail();
	}

	@Test
	public void ObjectCreated() {
		SqlUser_234a_t1 t1 = new SqlUser_234a_t1();
		ArrayList<String> items = new ArrayList<String>();
		items = t1.pullExistingItems();
	}

	@Test
	public void PullExistingWordsNotNull() {
		SqlUser_234a_t1 t1 = new SqlUser_234a_t1();
		ArrayList<String> items = new ArrayList<String>();
		items = t1.pullExistingItems();
		
		for (String item: items)
		{
//			System.out.println(item);			
		}
		assertTrue(items.get(0).equals("apples"));	
	}

	@Test
	public void PullUsersNotNull() {
		SqlUser_234a_t1 t1 = new SqlUser_234a_t1();
		ArrayList<User> users = new ArrayList<User>();
		users = t1.pullUsers();
		
		for (int i = 0; i <users.size(); i++)
		{
//			System.out.print(users.get(i).getFirstName() + ", ");
//			System.out.print(users.get(i).getLastName() + ", ");
//			System.out.print(users.get(i).getEmail() + ", ");
//			System.out.print(users.get(i).getUsername() + ", ");
//			System.out.print(users.get(i).getPassword() + ", ");
		}
	}
}
