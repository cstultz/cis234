package nsort.test;

import static org.junit.Assert.*;
import nsort.model.User;

import org.junit.Test;

@SuppressWarnings("unused")
public class User_UT {

	@Test
	public void testFail() {
		//fail();
	}

	@Test
	public void ObjectCreated() {
		User user = new User("Chris",                //First Name
				             "Stultz",               //Last Name
				             "cstultz@gmail.com",    //E-mail
				             "cstultz",              //Username
				             "P@ssword1!");          //Password
		String name = user.getFirstName();
	}
}
