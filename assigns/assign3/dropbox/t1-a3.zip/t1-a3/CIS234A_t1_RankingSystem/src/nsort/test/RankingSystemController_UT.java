package nsort.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class RankingSystemController_UT {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
