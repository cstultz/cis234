package nsort.model;

public class RankingSystemController {

}
