package nsort.test;

import static org.junit.Assert.*;

import org.junit.Test;

@SuppressWarnings("unused")
public class LoginScreen_UT {

	@Test
	public void testFail() {
		//fail();
	}

}
