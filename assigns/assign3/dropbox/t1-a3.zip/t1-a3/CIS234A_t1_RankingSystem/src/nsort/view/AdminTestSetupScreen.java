package nsort.view;

import java.awt.Container;
import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.AbstractListModel;

import nsort.model.*;

@SuppressWarnings({ "unused", "serial" })
public class AdminTestSetupScreen extends JFrame {

	private JPanel contentPane;
	private JTextField addWordTextField;
	private DefaultListModel<String> listModel;

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public AdminTestSetupScreen() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 889, 647);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 853, 587);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblAdminTestSetupPage = new JLabel("Admin NTest Setup");
		lblAdminTestSetupPage.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblAdminTestSetupPage.setBounds(300, 11, 253, 27);
		panel.add(lblAdminTestSetupPage);
		
		JLabel lblExitingItems = new JLabel("Exiting Words");
		lblExitingItems.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblExitingItems.setBounds(34, 49, 125, 22);
		panel.add(lblExitingItems);
		
		JComboBox<String> cbExistingTests = new JComboBox<String>();
		cbExistingTests.setMaximumRowCount(4);
		cbExistingTests.setToolTipText("List of Tests");
		cbExistingTests.setBounds(213, 441, 180, 20);
		panel.add(cbExistingTests);
		
		JLabel lblExistingTests = new JLabel("Existing Tests");
		lblExistingTests.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblExistingTests.setBounds(242, 396, 123, 22);
		panel.add(lblExistingTests);
		
		JLabel lblTestItems = new JLabel("WordList Words");
		lblTestItems.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTestItems.setBounds(253, 49, 101, 22);
		panel.add(lblTestItems);
		
		JLabel lblAddWord_or_Phrase = new JLabel("Add a word or phrase:");
		lblAddWord_or_Phrase.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAddWord_or_Phrase.setBounds(21, 399, 155, 17);
		panel.add(lblAddWord_or_Phrase);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(51, 480, 89, 23);
		panel.add(btnSubmit);
		
		addWordTextField = new JTextField();
		addWordTextField.setBounds(12, 441, 172, 20);
		panel.add(addWordTextField);
		addWordTextField.setColumns(10);
		
		JTextArea txtrInstructionsGoHere = new JTextArea();
		txtrInstructionsGoHere.setText("Instructions go here");
		txtrInstructionsGoHere.setEditable(false);
		txtrInstructionsGoHere.setBounds(464, 82, 379, 375);
		panel.add(txtrInstructionsGoHere);
		
		JButton btnFinish = new JButton("Finish");
		btnFinish.setBounds(320, 542, 89, 23);
		panel.add(btnFinish);
		
		JLabel lblOr = new JLabel("OR");
		lblOr.setBounds(419, 546, 15, 14);
		panel.add(lblOr);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Container frame = btnCancel.getParent();
	            do 
	                frame = frame.getParent(); 
	            while (!(frame instanceof JFrame));                                      
	            ((JFrame) frame).dispose();
			}
		});
		btnCancel.setBounds(444, 542, 89, 23);
		panel.add(btnCancel);
		
		JScrollPane existingItemsScrollPane = new JScrollPane();
		existingItemsScrollPane.setBounds(9, 82, 175, 300);
		panel.add(existingItemsScrollPane);
		
		JList existingItemsList = new JList();
		existingItemsScrollPane.setViewportView(existingItemsList);
		
		JScrollPane testItemsScrollPane = new JScrollPane();
		testItemsScrollPane.setBounds(216, 82, 175, 300);
		panel.add(testItemsScrollPane);
		
		JList testItemsList = new JList();
		testItemsScrollPane.setViewportView(testItemsList);
		
		//JScrollPane scrollPaneTestItems = new JScrollPane();
		//scrollPaneTestItems.setBounds(216, 82, 175, 300);
		//panel.add(scrollPaneTestItems);
		
		//JList<String> listTestItems = new JList<String>();
		//scrollPaneTestItems.setViewportView(listTestItems);
		
		//JScrollPane scrollPaneExistingItems = new JScrollPane();
		//scrollPaneExistingItems.setBounds(9, 82, 175, 300);
		//panel.add(scrollPaneExistingItems);
		
		SqlUser_234a_t1 t1 = new SqlUser_234a_t1();
		ArrayList<String> items = new ArrayList<String>();
		items = t1.pullExistingItems(); 
		
		//************************************************Load Existing Words from Database************************************************		
		String[] listOfExistingItems = new String[items.size()];
		
		for (int i = 0; i< items.size(); i++)
		{
			listOfExistingItems[i] = items.get(i);
		}
		String[] existingItems = listOfExistingItems;
		JList listExistingItems;
		listExistingItems = new JList(existingItems);
		existingItemsScrollPane.setViewportView(listExistingItems);
		//************************************************Load Existing Words from Database************************************************		
}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addExistingWordsToList()
	{
		listModel = new DefaultListModel();
	}
}
