package nsort.test;

import static org.junit.Assert.*;
import nsort.model.*;
import nsort.view.*;

import org.junit.Test;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextArea;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.AbstractListModel;

@SuppressWarnings("unused")
public class AdminTestSetupScreen_UT {

	@Test
	public void testFail() {
		//fail();
	}
	
	@Test
	public void testObjectCreation() {
		AdminTestSetupScreen adminTestSetup = new AdminTestSetupScreen();
		assertNotNull("adminTestSetup object is null", adminTestSetup);
	}

}
