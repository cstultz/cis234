/**
 * 
 */
package nsort.test;

/**
 * @author (Chris.Stultz, John.Loranger, Ryan.Reams, Josh.Eads) 
 * @version (4/14/2015)
 */
public class QuestionList_UT {


//	@Test
//	public void testGetQuestionsInstantiate() {
//		ItemList items = new ItemList();
//		QuestionList questions = new QuestionList(items);
//		assertNotNull("Instantiate failed.", questions);
//	}
//
//	@Test
//	public void testGetQuestionsZero() {
//		ItemList items = new ItemList();
//		QuestionList questions = new QuestionList(items);
//		assertTrue("Questions List is not empty.",  questions == null);
//	}
//
//	@Test
//	public void testGetQuestionsOne() {
//		Item item = new Item();
//		item.setValue("chewy");
//		ItemList items = new ItemList();
//		items.addItem(item);
//		QuestionList questions = new QuestionList(items);
//		assertEquals("Questions array size is not one.", questions.size(),  questions.size());
//	}
//
//	@Test
//	public void testGetQuestionsTwo() {
//		Item item1 = new Item();
//		Item item2 = new Item();
//		item1.setValue("chewy");
//		item1.setValue("chunky");
//		ItemList items = new ItemList();
//		items.addItem(item1);
//		items.addItem(item2);
//		QuestionList questions = new QuestionList(items);
//		assertEquals("Questions array size is not two.", questions.size(),  questions.size());
//	}
	
//	@Test
//	public void getNTestInstantiation1() {
//		ItemList items = new ItemList();
//		QuestionList questionList = new QuestionList(items);
//		assertNotNull("Instantiation failed.", questionList);
//	}
}