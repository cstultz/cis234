package nsort.controller;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

import nsort.model.Item;
import nsort.model.ItemList;
import nsort.model.SqlUser_234a_t1;
import nsort.model.User;
import nsort.view.AdminTestSetupFrame;
import nsort.view.LoginFrame;

/**
 * The RankingSystem class is the controller for the Ranking System application. 
 * Input will come from the view objects to the controller to encapsulate the 
 * business logic between the view and the model. 
 *  
 * @author (Chris.Stultz, John.Loranger, Ryan.Reams, Josh.Eads) 
 * @version (4/17/2015)
 */
public class RankingSystemController {
	
	private SqlUser_234a_t1 sqlUser;
	
	private LoginFrame loginFrame;
	private AdminTestSetupFrame adminTestSetupFrame;
	
	private ItemList existingItemsList;
	private ItemList testItemsList;

	/**
	 * Constructor for the RankingSystemController
	 */
	public RankingSystemController()
	{
		sqlUser = new SqlUser_234a_t1();  //initialize the SqlUser_234a_t1 class object 
	}
	
	/**
	 * This method starts the application and presents the loginFrame to the user.
	 */
	public void start()
	{
		loginFrame = new LoginFrame(this);
		loginFrame.setVisible(true);
	}
	
	/**
	 * The logic for the user login. Upon successful login will determine if the user is an admin or a test taker.
	 * @param username the value entered by the user during login
	 */
	public void login(String username)
	{
		if (sqlUser.validateUser(username))
		{
			if (sqlUser.isUserAccessAdmin(username))
			{
				loginFrame.setVisible(false);
				adminTestSetupFrame = new AdminTestSetupFrame(this);
				adminTestSetupFrame.setVisible(true);
			}
			else
			{
				User user = sqlUser.getUser(username);
				JOptionPane.showMessageDialog(null,"Sorry '" + user.getFirstName() + " " + user.getLastName() + "' The User Test has not yet been implemented.","User Test Coming Soon",JOptionPane.WARNING_MESSAGE);
			}
		}
		else
		{
			JOptionPane.showMessageDialog(null,"'" + username + "' is not a valid username.","Invalid username",JOptionPane.WARNING_MESSAGE);
		}
	}
	
	/**
	 * Populates the specific list (Existing Items or Test Items) with values pulled from the 
	 * specific database table (Item or TestItems) specified by the DefaultListModel and listName provided. 
	 * @param JListModel the DefaultListModel object to be populated
	 * @param listName the name of the DefaultListModel
	 */
	public void loadItemsToList(DefaultListModel<String> JListModel, String listName)
	{
		ItemList items = new ItemList();
		
		items = sqlUser.pullItems(listName);                  //pull the items from the database
		
		for (int i = 0; i < items.getSize(); i++)
		{
			Item item = items.getItem(i);
			String value = item.getValue();
			JListModel.addElement(value);                     //add each item to the DefaultListModel view
		}
		
		if (listName.equalsIgnoreCase("Existing Items"))
		{
			existingItemsList = items;                        //update the existing list in the model with the pull from the database
		}
		else if (listName.equalsIgnoreCase("Test Items"))
		{
			testItemsList = items;                            //update the test items list in the model with the pull from the database
		}
	}

	/**
	 * remove an item from the Test Items list
	 * @param JListModel the Test Items List object to be populated
	 * @param value of the item being removed
	 */
	public void removeItemFromTestItemList(DefaultListModel<String> JListModel, String value)
	{
		                                     //nothing is saved to the database at this time until the admin clicks the 'Finish' button.
		JListModel.removeElement(value);     //update the view
		testItemsList.removeItem(value);     //update the model
	}

	/**
	 * adds the new item to the Existing Items List and the Items table in the database. 
	 * @param JListModel the DefaultListModel object to be populated
	 * @param value of the item being added
	 */
	public void addNewItemToExistingItemsList(DefaultListModel<String> JListModel, String value)
	{
		if (listIsUnique(JListModel, value))      //check to make sure the item is not already on the list.
		{
			Item item = new Item();               //create the new Item
			item.setValue(value);                 //set the value of the item
			
			existingItemsList.addItem(item);      //update the model
			JListModel.addElement(value);         //update the view
			sqlUser.addNewItem(item);             //update the database
		}
		else
		{
			String input = "";
			for (int i = 0; i < JListModel.size(); i++)
			{
					if (JListModel.getElementAt(i).equalsIgnoreCase(value))
					{
						input = JListModel.getElementAt(i);
								if (value.equalsIgnoreCase(input)) break;
					}
			}
			
			JOptionPane.showMessageDialog(null,"'" + input + "' item already exists in the Existing Items List.","Duplicate item",JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * Checks to see if the user input value already exists on the specified list
	 * @param jListModel the DefaultListModel object to be checked
	 * @param value of the item being checked
	 * @return true if list is unique; false if not.
	 */
	public boolean listIsUnique(DefaultListModel<String> JListModel, String value)
	{
		for (int i = 0; i < JListModel.size(); i++)
		{
				if (JListModel.getElementAt(i).equalsIgnoreCase(value))
				{
					return false;
				}
		}
		return true;
	}

	/**
	 * add an existing item from the Existing Items List to the Test Items List
	 * @param JListModel the DefaultListModel object to be populated
	 * @param value of the item being added
	 */
	public void addExistingItemToTestItemsList(DefaultListModel<String> JListModel, String value)
	{
		
		
		if (listIsUnique(JListModel, value))
		{
			JListModel.addElement(value);         //update the view
			
			Item item = new Item();               //create the new Item
			item.setValue(value);                 //set the value of the item
			
			testItemsList.addItem(item);          //update the model
		}
		else
		{
			String input = "";
			for (int i = 0; i < JListModel.size(); i++)
			{
					if (JListModel.getElementAt(i).equalsIgnoreCase(value))
					{
						input = JListModel.getElementAt(i);
								if (value.equalsIgnoreCase(input)) break;
					}
			}
			
			JOptionPane.showMessageDialog(null,"'" + input + "' item already exists in the Test Items List.","Duplicate item",JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * Checks to see if the Test Item List meets the minimum requirements for a test (test items list >= 2)
	 * @return true if minimum requirements of the test are met; false if not.
	 */
	public boolean testItemsListMeetsMinimumRequirements(DefaultListModel<String> testItemsListModel)
	{
		if (testItemsListModel.size() >= 2)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * Creates an Item List of the DefaultListModel<String> from the specified view of the 
	 * DefaultListModel provided.
	 * @param JListModel the specific DefaultListModel being referenced
	 * @return The ItemList of values created 
	 */
	public ItemList modelToList(DefaultListModel<String> JListModel)
	{
		ItemList newList = new ItemList();
		for (int i = 0; i < JListModel.size(); i++)
		{
			Item item = new Item();
			item.setValue(JListModel.getElementAt(i));
			newList.addItem(item);
		}
		return newList;
	}
	
	/**
	 * Saves the administrator newly created test, logs off the user and returns them to the login screen
	 * 
	 * @param itemList The list being saved
	 */
	public void saveTestList(ItemList itemList)
	{
		testItemsList = itemList;          //updated the model
		sqlUser.saveTest(itemList);        //updated the database

		adminTestSetupFrame.setVisible(false);

		JOptionPane.showMessageDialog(null,"New test has been saved successfully to the database. You will now be logged off and returned to the login screen.","New Test Saved",JOptionPane.WARNING_MESSAGE);
		
		loginFrame.setVisible(true);
	}
	
	/**
	 * discards any change and preserves the previous test and then logs off the user and returns them to the login screen
	 * 
	 */
	public void cancelTest()
	{
		adminTestSetupFrame.setVisible(false);
		
		JOptionPane.showMessageDialog(null,"New test has been cancelled. Previous test has been preserved. You will now be logged off and returned to the login screen.","New Test Cancelled",JOptionPane.WARNING_MESSAGE);
		
		loginFrame.setVisible(true);
	}
	
	/**
	 * returns the existing items list
	 * 
	 * @return the existing items list
	 */
	public ItemList getExistingItemsList()
	{
		return existingItemsList;
	}
	
	/**
	 * returns the test items list
	 * 
	 * @return the test items list
	 */
	public ItemList getTestItemsList()
	{
		return testItemsList;
	}
	
}
