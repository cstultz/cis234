package nsort.controller;

/**
 * Implementation of controller for the nsort test taker.
 * Buttons for previous and next word allow navigation of the word list.
 * 
 * @author John Loranger, based heavily on template by Cara Tang
 */

import nsort.model.QuestionList;
import nsort.view.TakeTestView;

public class Controller {
	private QuestionList model;
	private TakeTestView view;

	public Controller(QuestionList model, TakeTestView view) {
		this.model = model;
		this.view = view;
		model.nextQuestion();
		updateView();
	}
	
	public void processNextItemEvent() {
		model.nextQuestion();
		updateView();
	}

	private void updateView() {
		view.updateQuestion(model.getCurrentQuestion());

	}
	
	public void processExitEvent() {
		System.exit(0);
		//todo - put any housekeeping /saving in here + verif this is a good way to shutdown. 
	}
	
}