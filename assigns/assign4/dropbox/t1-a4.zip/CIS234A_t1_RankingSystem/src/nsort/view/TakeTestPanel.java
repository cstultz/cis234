package nsort.view;

import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;


import nsort.model.Question;

/**
 * Panel to display a Question along with next button
 * 
 * @author John Loranger based heavily on template by Cara Tang
 */
@SuppressWarnings("serial")
public class TakeTestPanel extends JPanel {

	private static final Dimension DIM = new Dimension(400, 300);
	
	private JLabel itemLLabel;
	private JLabel itemRLabel;	
	private JButton nextButton;
	private JButton exitButton;
	
	public TakeTestPanel() {
		
		nextButton = new JButton("Next");
		exitButton = new JButton("exit");

		itemLLabel = new JLabel();
		itemRLabel = new JLabel();
		
		add(itemLLabel);
		add(itemRLabel);
		
		add(nextButton);
		add(exitButton);
		
		setPreferredSize(DIM);
	}
	
	/**
	 * Update the current question shown to the given question
	 * @param word  new current word
	 */
	public void setQuestion(Question question ) {
		itemLLabel.setText(question.getItemLeft().getValue());
		itemRLabel.setText(question.getItemRight().getValue());
	}
	
	/**
	 * Add the given listener to the "next" button
	 * @param al  an ActionListener
	 */
	public void addNextButtonListener(ActionListener al) {
		nextButton.addActionListener(al);
	}
	
	public void addExitButtonListener(ActionListener al) { 
		exitButton.addActionListener(al);
	}

}

