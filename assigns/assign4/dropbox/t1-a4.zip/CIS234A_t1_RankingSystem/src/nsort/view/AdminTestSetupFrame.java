package nsort.view;

import javax.swing.JFrame;

import nsort.controller.RankingSystemController;
/**
 * The AdminTestSetupFrame Class is the GUI for the administrator test setup for the Ranking System.
 *  
 * @author (Chris.Stultz, John.Loranger, Ryan.Reams, Josh.Eads) 
 * @version (4/25/2015)
 */
public class AdminTestSetupFrame extends JFrame 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private AdminTestSetupPanel basePanel;
	
	/**
	 * AdminTestSetupFrame object passing a reference to the RankingSystemControlelr
	 * for use by the Ranking System
	 * @param baseController
	 */
	public AdminTestSetupFrame(RankingSystemController baseController)
	{
		super("Ranking System - Admin Test Setup");
		basePanel = new AdminTestSetupPanel(baseController); 
		setupFrame();
	}
	
	/**
	 *Sets the content pane, size, and makes the frame visible. 
	 */
	private void setupFrame()
	{
		this.setContentPane(basePanel);
		this.setBounds(100, 100, 784, 564);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
}
