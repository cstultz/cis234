package nsort.view;
/**
 * Implementation of a word list view using a Swing GUI.
 * Buttons for previous and next word allow navigation of the word list.
 * 
 * @author Cara Tang
 * @author John Loranger adapted for Take Test views.
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import nsort.controller.Controller;
import nsort.model.Question;
import nsort.view.TakeTestView;  

@SuppressWarnings("serial")
public class TakeTestFrame extends JFrame implements TakeTestView {
	private TakeTestPanel takeTestPanel;
	private Controller controller;

	public TakeTestFrame() {
		super("Take Test");
		
		takeTestPanel = createNTestPanel();
		
		getContentPane().add(takeTestPanel);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
	}

	private TakeTestPanel createNTestPanel() {
		TakeTestPanel takeTestPanel = new TakeTestPanel();
		takeTestPanel.addNextButtonListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				controller.processNextItemEvent();
			}	
		});

		takeTestPanel.addExitButtonListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				controller.processExitEvent();
			}	
		});

		return takeTestPanel;
	}

	/**
	 * Update the current item shown in this view to newItem.
	 * 
	 * @param newItem  the new current item
	 */
	@Override
	public void updateQuestion(Question newQuestion) {
		takeTestPanel.setQuestion(newQuestion);
	}

	/**
	 * Register the given controller with this view.
	 * Methods on the controller are invoked when events in the view occur that could change the model.
	 * 
	 * @param controller  the word list controller to register with this view
	 */
	@Override
	public void registerController(Controller controller) {
		this.controller = controller;
	}
}
