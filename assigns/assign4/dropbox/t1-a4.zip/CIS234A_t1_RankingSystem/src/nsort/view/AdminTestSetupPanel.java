package nsort.view;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;

import nsort.controller.RankingSystemController;
import javax.swing.SwingConstants;

/**
 * The AdminTestSetupPanel Class contains the components for the admin test.
 *  
 * @author (Chris.Stultz, John.Loranger, Ryan.Reams, Josh.Eads) 
 * @version (4/25/2015)
 */
public class AdminTestSetupPanel extends JPanel 
{
	/**
	 * default serialization UID
	 */
	private static final long serialVersionUID = 1L;

	private RankingSystemController controller;
	
	private JLabel existingItemsLabel;
	private JList<String> existingItemsList;
	private DefaultListModel<String> existingItemsListModel;
	private JScrollPane existingItemsScrollPane;

	private JLabel addItemLabel;
	private JTextField addItemTextField;
	private JButton SubmitButton;
	
	private JLabel testItemsLabel;
	private JList<String> testItemsList;
	private DefaultListModel<String> testItemsListModel;
	private JScrollPane testItemsScrollPane;
	
	private JLabel adminTestSetupPageLabel;
	private JTextArea instructionsTextArea = new JTextArea();
	
	private JButton finishButton;
	private JLabel lblOr;
	private JButton cancelButton;
	
	//private GroupLayout baseLayout;
	
	/**
	 * AdminTestSetupPanel object passing a reference to the RankingSystemController
	 * for use by the RankingSystem
	 * @param baseController
	 */
	public AdminTestSetupPanel(RankingSystemController controller)
	{
		this.controller = controller;
		
		adminTestSetupPageLabel = new JLabel("Admin Test Setup");
		existingItemsLabel = new JLabel("Existing Items");
		testItemsLabel = new JLabel("Test Items");
		addItemLabel = new JLabel("Add an item");
		addItemTextField = new JTextField();
		SubmitButton = new JButton("Submit");

		finishButton = new JButton("Finish");
		lblOr = new JLabel("OR");
		lblOr.setHorizontalAlignment(SwingConstants.CENTER);
		cancelButton = new JButton("Cancel");
		
		//PROJECT REQUIREMENT
		finishButton.setEnabled(false);

		instructionsTextArea.setBackground(UIManager.getColor("Panel.background"));
		instructionsTextArea.setEditable(false);

		existingItemsListModel = new DefaultListModel<String>();
		existingItemsScrollPane = new JScrollPane();
		
		controller.loadItemsToList(existingItemsListModel, existingItemsLabel.getText());

		testItemsScrollPane = new JScrollPane();
		testItemsListModel = new DefaultListModel<String>();

		controller.loadItemsToList(testItemsListModel, testItemsLabel.getText());

		//baseLayout = new GroupLayout(this);

		setupPanel();
		setupLayout();
		setupListeners();
	}
	
	public void setupLayout()
	{
		adminTestSetupPageLabel.setBounds(490, 70, 193, 27);
		existingItemsLabel.setBounds(30, 32, 129, 22);
		testItemsLabel.setBounds(240, 32, 96, 22);
		addItemLabel.setBounds(10, 415, 83, 17);
		addItemTextField.setBounds(103, 415, 190, 20);
		SubmitButton.setBounds(303, 414, 76, 23);
		finishButton.setBounds(289, 475, 76, 23);
		lblOr.setBounds(375, 479, 20, 14);
		cancelButton.setBounds(400, 475, 76, 23);
		instructionsTextArea.setBounds(420, 108, 333, 184);
		existingItemsScrollPane.setBounds(10, 70, 168, 310);
		testItemsScrollPane.setBounds(198, 70, 181, 310);

		adminTestSetupPageLabel.setFont(new Font("Tahoma", Font.BOLD, 22));
		existingItemsLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		testItemsLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		addItemLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		instructionsTextArea.setFont(new Font("Arial", Font.PLAIN, 13));

		instructionsTextArea.setText("INSTRUCTIONS:\r\n\u2022 To " + addItemLabel.getText() + " to the list of " + existingItemsLabel.getText() + ":" +
                "\r\n     1. Type the new item into the " + addItemLabel.getText() + " text box." + 
                "\r\n     2. Click 'Submit'." + 
                "\r\n\u2022 To add an item to the list of " + testItemsLabel.getText() + ":" + 
                "\r\n     1. Double-click the item in the " + existingItemsLabel.getText() + " List." + 
                "\r\n\u2022 To remove an item from the list of " + testItemsLabel.getText() + ":" + 
                "\r\n     1. Double-click the item in the " + testItemsLabel.getText() + " List." + 
                "\r\n\u2022 To discard the current changes to the list of " + testItemsLabel.getText() + ":" + 
                "\r\n     1. Click " + cancelButton.getText() + "." +
                "\r\n\u2022 To keep the current changes to the list of " + testItemsLabel.getText() + ":" +
                "\r\n     1. Click " + finishButton.getText() + ".");
}
	
	public void setupPanel()
	{
		this.setSize(765,507);
		//this.setLayout(baseLayout);

		setLayout(null); //TODO setup layout
			
		add(existingItemsLabel);
		add(testItemsLabel);
		add(adminTestSetupPageLabel);
		add(addItemLabel);
		add(addItemTextField);
		add(SubmitButton);
		add(existingItemsScrollPane);
		add(testItemsScrollPane);
		add(instructionsTextArea);
		add(finishButton);
		add(lblOr);
		add(cancelButton);
		
		existingItemsList = new JList<String>(existingItemsListModel);
		existingItemsScrollPane.setViewportView(existingItemsList);
		existingItemsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		testItemsList = new JList<String>(testItemsListModel);
		testItemsScrollPane.setViewportView(testItemsList);
		testItemsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

	}
	
	public void setupListeners()
	{
		/**
		 * click event for adding a new item to the existing items list
		 */
		SubmitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{	
				//SUBMIT BUTTON CLICKED
				controller.addNewItemToExistingItemsList(existingItemsListModel, addItemTextField.getText());
			}
		});
		
		/**
		 * enter key clicked inside the add item text field simulates a submit button click event
		 */
		addItemTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) 
			{
			   int key = e.getKeyCode();
		        
		        if (key == KeyEvent.VK_ENTER) 
		        {	
		        	//ENTER KEY PRESSED IN ADD ITEM TEXT BOX
		        	SubmitButton.doClick();
		        }
			}
		});

		/**
		 * admin disposes and changes to the test items list and keeps the previous test items list
		 */
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				//CANCEL BUTTON CLICKED
				controller.cancelTest();
			}
		});

		/**
		 * admin saves the newly created test items list of 2 or more items
		 */
		finishButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				//FINISH BUTTON CLICKED
				controller.saveTestList(controller.modelToList(testItemsListModel));
			}
		});

		/**
		 * user clicks an existing item to add to the test items
		 */
		existingItemsList.addMouseListener(new MouseAdapter()
		{
			//EXISTING ITEMS LIST DOUBLE CLICKED
			public void mousePressed(MouseEvent event)
			{
				if (event.getClickCount() == 2)
				{
					//ADDS EXISTING LIST ITEM TO TEST LIST ITEMS
					controller.addExistingItemToTestItemsList(testItemsListModel, existingItemsList.getSelectedValue());
					//PROJECT REQUIREMENT
					finishButton.setEnabled(controller.testItemsListMeetsMinimumRequirements(testItemsListModel));
				}
			}
		});
		
		/**
		 * user clicks a test item to remove the item from the test items list
		 */
		testItemsList.addMouseListener(new MouseAdapter()
		{
			//TEST ITEMS LIST DOUBLE CLICKED 
			public void mousePressed(MouseEvent event)
			{
				if (event.getClickCount() == 2)
				{
					//REMOVES ITEM FROM THE TEST ITEMS LIST
					//testItemsListModel.removeElementAt(testItemsList.getSelectedIndex());
					controller.removeItemFromTestItemList(testItemsListModel, testItemsList.getSelectedValue());
					//PROJECT REQUIREMENT
					finishButton.setEnabled(controller.testItemsListMeetsMinimumRequirements(testItemsListModel));
				}
			}
		});
	}
}