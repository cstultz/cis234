package nsort.view;

/*
 * NTest Controller.  Controller class for NSort application
 * 
 *@author John Loranger, based heavily on template by Cara Tang.
 *@date   4/21/2015
 */

import nsort.controller.Controller;
import nsort.model.Question;

public interface TakeTestView {

	/**
	 * Update the current Item shown in this view to newItem.
	 * 
	 * @param newItem  the new current item
	 */
	public void updateQuestion(Question newQuestion);

	/**
	 * Register the given controller with this view.
	 * Methods on the controller are invoked when events in the view occur that could change the model.
	 * 
	 * @param controller  the word list controller to register with this view
	 */
	public void registerController(Controller controller);
	
}
