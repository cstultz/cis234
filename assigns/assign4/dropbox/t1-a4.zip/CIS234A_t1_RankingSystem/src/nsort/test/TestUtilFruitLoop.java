package nsort.test;

public class TestUtilFruitLoop { 
	
	private int i=0;
	
	public final static String[] itemStrings= {
		"Apples", 			"Bananas", 				"Cherries", 
		"Durian", 			"Entawak",				"Figs", 	
		"Grapefruit", 		"Huckleberry",			"Ita Palm",	
		
		"Jujube",			"Kiwi",					"Lemon",	
		"Mango",			"Nectarine",			"Olive",
		"Papaya",			"Quince",				"Radish",	
		
		"Starfruit",		"Tomatoe",				"Ugli",		
		"Voavanga",			"Watemelon",			"Xigua",	
		"Yellow Watermelon","Zucchini" 
	};
	
	TestUtilFruitLoop(){ reset(); };
	public void reset()  { this.i = 0; }
	public String circularNext() { return itemStrings[i++ % itemStrings.length] ; }
	public String[] getStrings() { return itemStrings.clone(); }

}
