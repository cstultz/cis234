package nsort.test;


import nsort.controller.Controller;
import nsort.model.QuestionList;
import nsort.view.TakeTestFrame;
//import edu.pcc.cis234a.mvcdemo.controller.WordListController;
//import edu.pcc.cis234a.mvcdemo.model.WordList;
//import edu.pcc.cis234a.mvcdemo.view.WordListReaderFrame;
//import edu.pcc.cis234a.mvcdemo.view.WordListView;

/**
 * Demo the model-view-controller pattern.
 * Model is a list of questions that can be traversed. From the "current" question the model allows moving to the next question.
 * View is a simple GUI that displays the current question as a two items & a changeable radio
 * button Answer to be decided upon.  User (does/does not) update Answer radio, then clicks Next button.
 * @author John Loranger based on MVC example by Cara Tang.
 */
public class DriverMain {

	public static void main(String[] args) {
		
		//WordList model = new WordList();
		QuestionList model = new QuestionList();
		//model.setWords(createWordList());
		model.setQuestions( TestUtilQuestions.getQuestions(5)  );

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
			//	WordListView view = new WordListReaderFrame();		
				TakeTestFrame view = new TakeTestFrame();
			//	WordListController controller = new WordListController(model, view);
				Controller controller = new Controller( model, view );
				view.registerController(controller);
			}
		});
	}
}
