package nsort.test;

import nsort.view.TakeTestPanel;
import javax.swing.JFrame;


import org.junit.Before;
import org.junit.Test;

public class TestTakeTestPanel {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testTakeTestPanelInstantiation() {
		@SuppressWarnings("unused")
		TakeTestPanel takeTestPanel = new TakeTestPanel();
	}

	@Test
	public void testTODODONTLEAVEME_tryingtoautomate() {

		
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				TakeTestPanel takeTestPanel = new TakeTestPanel();
				takeTestPanel.setVisible(true);

				JFrame frame = new JFrame("Test testTODODONTLEAVEME_tryingtoautomate");
				frame.getContentPane().add(takeTestPanel);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.add(takeTestPanel);
				frame.pack();
			}
		});
	}

/*
	@Test
	public void testAddNextButtonListener() {
		fail("Not yet implemented"); // TODO
	}
*/
}
