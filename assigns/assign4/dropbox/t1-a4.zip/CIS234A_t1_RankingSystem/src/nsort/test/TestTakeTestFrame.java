package nsort.test;

import nsort.view.TakeTestFrame;
import org.junit.Before;
import org.junit.Test;

public class TestTakeTestFrame {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testTakeTestFrameIntantiation() {
		@SuppressWarnings("unused")
		TakeTestFrame takeTestFrame = new TakeTestFrame();		
	}
	
/*
	@Test
	public void testUpdateQuestion() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRegisterController() {
		fail("Not yet implemented"); // TODO
	}
*/
}
