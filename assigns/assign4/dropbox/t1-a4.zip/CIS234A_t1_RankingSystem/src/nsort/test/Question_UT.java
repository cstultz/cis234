/**
 * 
 */
package nsort.test;

import static org.junit.Assert.*;

import nsort.model.Answer;
import nsort.model.Question;

import org.junit.Test;

/**
 * Unit nsort.test to nsort.test Question object.
 * 
 * @author 	john_loranger
 * @date 	04/21/2015
 *
 */
public class Question_UT {

	
	/**
	 * Test method for {@link nsort.model.Question#Question(java.lang.String)}.
	 */
	@Test
	public void testQuestionInstantiation() {
		Question question = new Question();
		assertNotNull("Question instantiation failed.", question);
	}

	/**
	 * Test method for {@link nsort.model.Question#getAnswer()}.
	 */
	@Test
	public void testGetAnswerWithDefault() {
		Question question = new Question();		
		Answer answer = question.getAnswer();
		
		assertNotNull("Answer answer is null", answer);
		
		assertEquals("Question answer default not expected UNANSWERED value",  Answer.Value.UNANSWERED,  answer.getValue());
	}

	/**
	 * Test method for {@link nsort.model.Question#setAnswer()}.
	 */
	@Test
	public void testSetValue() {
		Answer answer = new Answer();
		answer.setValue(Answer.Value.LEFT);

		Question question = new Question();
		question.setAnswer(answer);					// so now questions answer is LEFT
		 
		assertEquals("Question getAnswer did not return setAnswer'd value", question.getAnswer(), answer) ; 
	}

	/**
	 * Test method for {@link nsort.model.Question#getAnswer()}.
	 * This is the same as Set Value test, but with different data.  
	 * 
	 */
	@Test
	public void testGetValue() {
		Answer answer = new Answer();
		answer.setValue(Answer.Value.RIGHT);

		Question question = new Question();
		question.setAnswer(answer);					// so now questions answer is RIGHT
		 
		assertEquals("Question getAnswer did not return setAnswer'd value", question.getAnswer(), answer) ; 
	}

}
