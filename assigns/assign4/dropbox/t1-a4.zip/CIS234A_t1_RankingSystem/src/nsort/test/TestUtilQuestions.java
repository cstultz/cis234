package nsort.test;

import java.util.LinkedList;
import java.util.List;

import nsort.model.Item;
import nsort.model.Question;

public class TestUtilQuestions {


	public static List<Question> getQuestions( int numQuestionsRequested ) {
		return getQuestions(numQuestionsRequested, false );
	}

	// 	create and return numQuestionsRequested list of questions. 
	public static List<Question> getQuestions( int numQuestionsRequested, boolean verbose ) {

		LinkedList<Question> questions = new LinkedList<Question>();
		TestUtilFruitLoop fruitLoop = new TestUtilFruitLoop();
		for ( int qi= 0; qi < numQuestionsRequested; qi++ ) {		
			
			Question question = new Question();
			Item itemLeft = new Item();
			Item itemRight = new Item();
			itemLeft.setValue( fruitLoop.circularNext() );
			question.setItemLeft( itemLeft );
			itemRight.setValue( fruitLoop.circularNext() );
			question.setItemRight( itemRight );
			questions.add( question ); 
		
		}
		
		if ( verbose ) {
			System.out.println("getQuestions test function is returning these questions: ");
			for ( int k=0; k<questions.size(); k++){
				System.out.print(""+k+" " + questions.get(k).getItemLeft().getValue());
				System.out.println("," + questions.get(k).getItemRight().getValue()+"  " + 
				questions.get(k).getAnswer().getValue() );
			}
		}
	
		return questions;		
	}
}
