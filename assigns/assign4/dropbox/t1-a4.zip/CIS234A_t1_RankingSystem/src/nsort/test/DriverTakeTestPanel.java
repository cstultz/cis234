package nsort.test;

/**
 * View showing test taking screen. User can start test and iterate through questions.
 * 
 * @author John Loranger based on template by Cara Tang
 * @date   April 21, 2015
 */



import javax.swing.JFrame;

import nsort.view.TakeTestPanel;

public class DriverTakeTestPanel{
	
	public static void main(String[] args) {
		System.out.println("DriverTakeTestPanel starts....");
				
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				
				TakeTestPanel takeTestPanel = new TakeTestPanel();
				JFrame frame = new JFrame("Driver Testing Class TakeTestPanel");
				frame.getContentPane().add(takeTestPanel);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.add(takeTestPanel);
				frame.pack();
				frame.setVisible(true);
			}
		});
		
	}
}

