/**
 * 
 */
package nsort.test;

//TODO need some test sets for testing questionList answer values

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import nsort.model.Question;
import nsort.model.QuestionList;

import org.junit.Test;

public class TestQuestionList {


	@Test
	public void testGetQuestionsInstantiate() {
		List<Question> questions = TestUtilQuestions.getQuestions(0);
		assertNotNull("Instantiate failed.", questions);
	}

	@Test
	public void testGetQuestionsZero() {
		List<Question> questions = TestUtilQuestions.getQuestions(0);
		assertTrue("Questions array is not empty.",  questions.isEmpty());
	}

	@Test
	public void testGetQuestionsOne() {
		int siz = 1; 
		List<Question> questions = TestUtilQuestions.getQuestions(siz);
		assertEquals("Questions array size is not one.", siz ,  questions.size());
	}

	@Test
	public void testGetQuestionsTwo() {
		int siz = 2; 
		List<Question> questions = TestUtilQuestions.getQuestions(siz);
		assertEquals("Questions array size is not one.", siz ,  questions.size());
	}
	
	@Test
	public void testGetQuestionsEighteen() {
		int siz = 18; 
		List<Question> questions = TestUtilQuestions.getQuestions(siz);
		assertEquals("Questions array size is not one.", siz ,  questions.size());
	}

	@Test
	public void testGetQuestionsNineteen() {
		int siz = 19; 
		List<Question> questions = TestUtilQuestions.getQuestions(siz);
		assertEquals("Questions array size is not one.", siz ,  questions.size());
	}

	@Test
	public void testGetQuestionsCoverage() {

		int siz = 100; 

		List<Question> questions = TestUtilQuestions.getQuestions(siz, true);
		List<String> availableStrings = new ArrayList<> (Arrays.asList(TestUtilFruitLoop.itemStrings)); 

		assertEquals("availableStrings should be 18 and is not", 26, availableStrings.size());

		Question question;
		String str;

		for ( int i=0; !availableStrings.isEmpty() && i<siz ; i++ ) {
			question = questions.get(i); 
			
			str = question.getItemLeft().getValue();

			if ( availableStrings.contains(str)) {
				System.out.print("Removing " +str );
				availableStrings.remove(str); 
			}
			str = question.getItemRight().getValue();
			
			if ( availableStrings.contains(str)) {
				System.out.println(", " +str +"" );
				availableStrings.remove(str);
			}
			
		}
		assertTrue("(statistically improbable) Not all elements of availableStrings used", 
				availableStrings.isEmpty());
	}

	@Test
	public void getNTestInstantiation1() {
		QuestionList questionList = new QuestionList();
		assertNotNull("Instantiation failed.", questionList);
	}

	
	@Test
	public void testTestGetQuestionsWithNoQuestions() {
		QuestionList questionList = new QuestionList();
		questionList.setQuestions( TestUtilQuestions.getQuestions(0, false) );
		assertEquals("number of questions input does not match numberOfQuestions call",0, 
				questionList.getQuestions().size() );
	}
	
	@Test
	public void testWithQuestionsQtyOne() {
		
		QuestionList questionList = new QuestionList();
		
		questionList.setQuestions(TestUtilQuestions.getQuestions(1, false));
		
		assertEquals("number of questions input does not match numberOfQuestions call",1, 
				questionList.getQuestions().size() );
	}

	@Test
	public void testWithQuestionsQtyTwo() {
		
		QuestionList questionList = new QuestionList();
		
		questionList.setQuestions(TestUtilQuestions.getQuestions(2, false));
		
		assertEquals("number of questions input does not match numberOfQuestions call",2, 
				questionList.getQuestions().size() );
	}

	@Test
	public void testWithQuestionsQty26000() {
		
		QuestionList questionList = new QuestionList();
		
		questionList.setQuestions(TestUtilQuestions.getQuestions(26000, false));
		
		assertEquals("number of questions input does not match numberOfQuestions call",26000, 
				questionList.getQuestions().size() );
	}

	
	@Test
	public void testNextQuestionWithQtyZero() {
		QuestionList questionList = new QuestionList();
		
		questionList.setQuestions(TestUtilQuestions.getQuestions(1, false));
		questionList.nextQuestion();
	}
	
	@Test
	public void testNextQuestionWithQtyOne() {
		QuestionList questionList = new QuestionList();
		
		questionList.setQuestions(TestUtilQuestions.getQuestions(1, false));
		questionList.nextQuestion();
	}


	@Test
	public void testNextQuestionQty1() {
		
		QuestionList questionList = new QuestionList();		
		questionList.setQuestions(TestUtilQuestions.getQuestions(1, false)); 
		
		assertNotNull("Call to getCurrent should not be null prior to first nextQuestion", questionList.getCurrentQuestion());
		questionList.nextQuestion();
		
		assertNull("Call to getCurrent should be null after first nextQuestion", questionList.getCurrentQuestion()); 
		
		TestUtilFruitLoop fruitLoop = new TestUtilFruitLoop(); 
			
		String expectedL = fruitLoop.circularNext();
		String actualL = questionList.getCurrentQuestion().getItemLeft().getValue();		
			
		assertEquals( "Left Item did not match", expectedL, actualL );

		String expectedR = fruitLoop.circularNext();
		String actualR = questionList.getCurrentQuestion().getItemRight().getValue();		

		assertEquals( "Right Item did not match", expectedR, actualR);
			
	}
	
	@Test
	public void testIteratorQty2() {

		QuestionList questionList = new QuestionList();		
		questionList.setQuestions(TestUtilQuestions.getQuestions(2, false)); 

		TestUtilFruitLoop fruitLoop = new TestUtilFruitLoop(); 
		
		{
			String expectedL = fruitLoop.circularNext();
			String actualL = questionList.getCurrentQuestion().getItemLeft().getValue();		
				
			assertEquals( "Question 1 Left Item did not match", expectedL, actualL );
	
			String expectedR = fruitLoop.circularNext();
			String actualR = questionList.getCurrentQuestion().getItemRight().getValue();		
	
			assertEquals( "Question 1 Right Item did not match", expectedR, actualR);
			questionList.nextQuestion();
		}
		questionList.nextQuestion();
		{
			String expectedL = fruitLoop.circularNext();
			String actualL = questionList.getCurrentQuestion().getItemLeft().getValue();		
				
			assertEquals( "Question 2 Left Item did not match", expectedL, actualL );
	
			String expectedR = fruitLoop.circularNext();
			String actualR = questionList.getCurrentQuestion().getItemRight().getValue();		
	
			assertEquals( "Question 2 Right Item did not match", expectedR, actualR);
			questionList.nextQuestion();
		}	
	}
	
	@Test
	public void testIteratorQty10000() {

		QuestionList questionList = new QuestionList();		
		questionList.setQuestions(TestUtilQuestions.getQuestions(10000, false)); 

		TestUtilFruitLoop fruitLoop = new TestUtilFruitLoop(); 
		
		while ( questionList.getCurrentQuestion() != null )
		{
			String expectedL = fruitLoop.circularNext();
			String actualL = questionList.getCurrentQuestion().getItemLeft().getValue();		
				
			assertEquals( "Question Left Item did not match", expectedL, actualL );
	
			String expectedR = fruitLoop.circularNext();
			String actualR = questionList.getCurrentQuestion().getItemRight().getValue();		
	
			assertEquals( "Question Right Item did not match", expectedR, actualR);
			
			questionList.nextQuestion();
		}
	}
	
}