package nsort.test;

import javax.swing.JFrame;

import nsort.view.TakeTestFrame;
import nsort.view.TakeTestPanel;

public class DriverTakeTestFrame{
	
	public static void main(String[] args) {
		System.out.println("DriverTakeTestFrame starts....");
				
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				
				TakeTestPanel takeTestPanel = new TakeTestPanel();
				TakeTestFrame frame = new TakeTestFrame();
				frame.getContentPane().add(takeTestPanel);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.add(takeTestPanel);
				frame.pack();
				frame.setVisible(true);
			}
		});
	}
}

