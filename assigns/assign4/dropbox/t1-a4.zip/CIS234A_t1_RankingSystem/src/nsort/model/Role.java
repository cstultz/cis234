package nsort.model;

/**
 * The Role class is the .....
 *  
 * @author (Chris.Stultz, John.Loranger, Ryan.Reams, Josh.Eads) 
 * @version (4/17/2015)
 */
public class Role {

} 
