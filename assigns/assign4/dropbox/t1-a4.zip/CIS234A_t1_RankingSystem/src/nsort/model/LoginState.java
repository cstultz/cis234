package nsort.model;

/**
 * The ######## class is the .....
 *  
 * @author (Chris.Stultz, John.Loranger, Ryan.Reams, Josh.Eads) 
 * @version (4/17/2015)
 */public class LoginState {

}
