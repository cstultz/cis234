/**
 * 
 */
package nsort.model;

/**
 * Answer represents the answer to a question.  A question may be answered or unanswered.
 * If it is answered, it can have a value of Left, Right, or CantDecide
 * @author john_loranger
 * @date   April 21, 2015
 */
public class Answer {
	
	// possible answer values
	public enum Value { LEFT, RIGHT, CANT_DECIDE, UNANSWERED };
	
	boolean 	isAnswer;  		 // true iff question is answered
	Value 		value;			 // only valid if question has been answered

	public Answer() { 
		setValue(Value.UNANSWERED); 
	}

	/**
	 * returns true if the question has been answered and this.value is populated.
	 * @return the isAnswered
	 */
	public boolean isAnswered() {
		return value != Value.UNANSWERED;
	}

	/**
	 * @return the value
	 */
	public Value getValue() {
		return this.value;
	}
	/**
	 * @param value the value to set
	 */
	
	public void setValue(Value value) {
		this.value = value;
	}
}
