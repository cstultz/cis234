/**
 * 
 */
package nsort.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author john_loranger
 *
 */
public class QuestionList {
	
	private List<Question> questions = new ArrayList<Question>();	

	private Question current = null;
	
	Iterator<Question> iterator;
	
	public void nextQuestion() { 
		if ( iterator.hasNext() ) {
			current =  iterator.next();
		} else {
			current = null;
		}
	}
	public QuestionList() { this.iterator = questions.iterator(); }
	
	public Question getCurrentQuestion() {return current; }
		
	public void setQuestions( List<Question> questions ) {
		this.questions = questions;
		iterator = questions.iterator();
	}
	
	public List<Question> getQuestions() {
		return questions;
	}
	
}

