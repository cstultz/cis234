/**
 * 
 */
package nsort.model;

import nsort.model.Answer;


/**
 * Question represents a question that is presented to the user. The user chooses their 
 * answer and this object is updated.   
 * @author john_loranger
 * @date 04/21/2015
 */
public class Question {

	private Item itemLeft;
	private Item itemRight;
	private Answer answer;

	public Question(){
		this.itemLeft = null;
		this.itemRight = null;
		this.answer = new Answer();  // so we have initial state of answer to be a valid answer state. 
	}
	
	/**
	 * @return the itemLeft
	 */
	public Item getItemLeft() {
		return itemLeft;
	}
	/**
	 * @param itemLeft the itemLeft to set
	 */
	public void setItemLeft(Item itemLeft) {
		this.itemLeft = itemLeft;
	}
	/**
	 * @return the itemRight
	 */
	public Item getItemRight() {
		return itemRight;
	}
	/**
	 * @param itemRight the itemRight to set
	 */
	public void setItemRight(Item itemRight) {
		this.itemRight = itemRight;
	}
	/**
	 * @return the answer
	 */
	public Answer getAnswer() {
		return answer;
	}
	/**
	 * @param cantDecide the answer to set
	 */
	public void setAnswer(Answer answer) {
		this.answer = answer;
	}
}
