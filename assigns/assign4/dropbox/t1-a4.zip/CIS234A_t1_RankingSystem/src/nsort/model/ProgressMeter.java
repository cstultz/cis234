package nsort.model;
import javax.swing.JProgressBar;

/**
 * The ProgressMeter class is the .....
 *  
 * @author (Chris.Stultz, John.Loranger, Ryan.Reams, Josh.Eads) 
 * @version (4/17/2015)
 */public class ProgressMeter extends JProgressBar{

  	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static boolean visible = true;
 	//Progress bar values. 'lowerBound' and 'upperBound' are for setting the progress bar. 
 	//'currentBound' is the current question number they're on.
 	@SuppressWarnings("unused")
	private int lowerBound;
 	@SuppressWarnings("unused")
	private int upperBound;
 	//private int currentBound = 0;
 	
 	public ProgressMeter (int x, int y, boolean visible) {
 		//Need to call the super class constructor bc of the extender. This way JProgressBar gets implemented
 		//and all the JProgressBar class elements are updated appropriately.
 		super (x, y);
 		lowerBound = x;
 		upperBound = y;
 		//setVisible = showBar;
 		//progBar =  new JProgressBar(lowerBound, upperBound);	
 		
 	}

	/**
	 * @return the visible
	 */
	public static boolean getVisible() {
		return visible;
	}

	/**
	 * @param visible the visible to set
	 */
	/*
	public static void setVisible(boolean visible) {
		ProgressMeter.visible = visible;
	}
	*/
 	}