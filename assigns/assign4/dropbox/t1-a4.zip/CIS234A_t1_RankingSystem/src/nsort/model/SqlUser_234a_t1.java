package nsort.model;

/**
 * The SqlUser234A_t1 class is the model for all connection operations to the 234a_t1 MS SQL database.
 * Only 1 test can be saved in the database at any given time. testID = 1
 * 
 * @author (Chris.Stultz, John.Loranger, Ryan.Reams, Josh.Eads) 
 * @version (4/17/2015)
 */
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class SqlUser_234a_t1 {

	private Connection conn = null;
	/**********************************database connection url*******************************************/
	private final static String url = "jdbc:sqlserver://cisdbss.pcc.edu;"
			           + " databaseName=234a_t1; "
			           + "user=234a_t1; "
			           + "password=1t_a432@#";
	
	/********************The One, The Only Test table testID to Rule them all****************************/
	private final static int theOneTheOnlyTestID = 1;
	/********************The One, The Only Test table testID to Rule them all****************************/
	
	/********************The One, The Only Test table testID to Rule them all****************************/
	private final static String adminAccessRole = "Admin";
	/********************The One, The Only Test table testID to Rule them all****************************/

	/**********************************queries for AdminTestSetupScreen)*********************************/
	private final static String queryDeleteTestItems = "DELETE FROM TestItems WHERE TestItems.test_ID = ?;";
	private final static String queryPullItemIDsByValue = "SELECT itemID FROM Item WHERE value = ?;";
	private final static String queryInsertTestItems = "INSERT INTO TestItems(test_ID, item_ID) VALUES (?, ?);";
	private final static String queryPullExistingItems = "SELECT [value] FROM [234a_t1].dbo.Item ORDER BY itemID;";
	private final static String queryPullTestItems= "SELECT [value] FROM Item JOIN TestItems ON Item.itemID = TestItems.item_ID WHERE TestItems.test_ID = "+ theOneTheOnlyTestID + " Order By Item.itemID;";
	private final static String queryCheckUser = "SELECT username FROM [User] WHERE username = ?;";
	private final static String queryGetUser = "SELECT firstName, lastName, eMail FROM [User] WHERE username = ?;";
	private final static String queryAddNewItem = "INSERT INTO Item(value) VALUES (?);";
	private final static String queryPullTestItemsCount = "SELECT COUNT(testItemsID) as [Count] FROM TestItems WHERE test_ID = ?;";
	private final static String queryPullUserAccessRole = "SELECT role FROM [User] JOIN UserAccess ON [User].userID = UserAccess.user_ID WHERE [User].username = ?;";
	/**********************************queries for AdminTestSetupScreen)*********************************/

	/**
     * Constructor for the class. Does nothing but construct the object.
     */
    public SqlUser_234a_t1()
    {
    	//do nothing
    }
    
    /**
     * Connects to the database. This must be called EVERYTIME you want to submit a statement to the
     * database. I learned this the hard way through trial and error. When looping make sure to nest the call
     * INSIDE your loop. Cheers. -Chris.
     */
    public void connect()
    {
		try
		{
			conn = DriverManager.getConnection(url);
    	}
		catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
    }
    
    /**
     * pulls list specific items from the database.
     * 
     * @param listNumber determines the specified list. 1 for Existing Items List; 2 for Test Items List
     * @return list of items returned from the database
     */
    public ItemList pullItems(String listName)
    {
    	connect();
    	
    	String query = "";
    	
    	if (listName.equalsIgnoreCase("Existing Items"))
    	{
    		query = queryPullExistingItems;
    		
    	}
    	else if (listName.equalsIgnoreCase("Test Items"))
    	{
    		query = queryPullTestItems;
    	}
    	else
    	{
    		//not sure if this is the correct type of error to display here.....
    		JOptionPane.showMessageDialog(null,"Internal Error. The listNumber parameter can only be 1 for Existing Items List or 2 for Test Items List","listNumber does not exist.",JOptionPane.WARNING_MESSAGE);
    	}
    	ItemList itemList = new ItemList();
    	Statement stmt = null;
    	
    	try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next())
			{
				String input = rs.getString("value");
				Item item = new Item();
				item.setValue(input);
				itemList.addItem(item);
			}
		}
		catch (SQLException e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
    	return itemList;
    }

    /**
     * saves the new test to the TestItems database. 
     * @param the list of items to be saved for the test.
     */
    public void saveTest(ItemList TestItemsList)
    {
    	ArrayList<Integer> itemIDList = new ArrayList<Integer>();
    	
    	deleteCurrentTestItems();
    	itemIDList = pullTestItemIDsByValue(TestItemsList, itemIDList);
    	addTestitems(itemIDList);
    }
    
    /**
     * deletes ALL the test items from the TestItems table in the database for theOneTheOnlyTestID.  
     */
    public void deleteCurrentTestItems()
    {
    	PreparedStatement preparedStmt;
		try {
			preparedStmt = conn.prepareStatement(queryDeleteTestItems);
	         preparedStmt.setInt(1, theOneTheOnlyTestID);
	         // execute the preparedstatement
	         preparedStmt.execute();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

    }
    
    /**
     * pulls the itemID into ArrayList<Integer> from the Items table in the database 
     * based on the value of each item in the testList ArrayList<String> provided.
     * @param the ArrayList<String> of item values listed on the new test.
     * @return the ArrayList<Integer> itemID from the Items table in the database.
     */
    public ArrayList<Integer> pullTestItemIDsByValue(ItemList itemList, ArrayList<Integer> itemIDList)
    {
		try {
			for (int i = 0; i < itemList.getSize(); i++)
			{
		    	connect();
				PreparedStatement preparedStmt = conn.prepareStatement(queryPullItemIDsByValue);
				preparedStmt.setString(1, itemList.getItem(i).getValue());
		         // execute the preparedstatement
		         ResultSet rs = preparedStmt.executeQuery();
		         while (rs.next())
		 			{
		 				int input = rs.getInt("itemID");
		        	    itemIDList.add(input);
		 			}
		         
			}
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return itemIDList;
	}
    
    /**
     * insert test items into the TestItems table in the database for theOneTheOnlyTestID
     * 
     * @param itemIDList
     */
    public void addTestitems(ArrayList<Integer> itemIDList)
    {
    	try {
    		connect();
    		PreparedStatement preparedStmt = conn.prepareStatement(queryInsertTestItems);
			for (int i : itemIDList) {
				preparedStmt.setInt(1, theOneTheOnlyTestID);
				preparedStmt.setInt(2, i);
				preparedStmt.addBatch();
			}
			preparedStmt.executeBatch();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    }
    
    /**
     * inserts the new item into the Items table in the database.  
     * @param value to be added to the database.
     */
    public void addNewItem(Item item)
    {
    	try {
    		connect();
    		PreparedStatement preparedStmt = conn.prepareStatement(queryAddNewItem);
			preparedStmt.setString(1, item.getValue());
			preparedStmt.execute();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    }
    
    /**
     * pulls ALL the users from the User table in the database
     * 
     * @return the users from the User table in the database
     */
    public boolean validateUser(String username)
    {
    	String value = " ";
    	try {
    		connect();
    		PreparedStatement preparedStmt = conn.prepareStatement(queryCheckUser);
			preparedStmt.setString(1, username);
			ResultSet rs = preparedStmt.executeQuery();
			while (rs.next())
			{
				value = rs.getString("username");
			}
			if (username.equalsIgnoreCase(value))
			{
				return true;
			}
			else return false;
		}
		catch (SQLException e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
    	return false;
    }

    /**
     * pulls a user from the User table in the database based on the username
     * 
     * @return the user from the User table in the database
     */
    public User getUser(String username)
    {
    	String firstName = "";
    	String lastName = "";
    	String eMail = "";
    	
    	User user;
    	
    	try {
    		connect();
    		PreparedStatement preparedStmt = conn.prepareStatement(queryGetUser);
			preparedStmt.setString(1, username);
			ResultSet rs = preparedStmt.executeQuery();
			while (rs.next())
			{
				firstName = rs.getString("firstName");
				lastName = rs.getString("lastName");
				eMail = rs.getString("eMail");
			}
			
			user = new User(firstName, lastName, eMail, username);
			return user;

		}
		catch (SQLException e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
    	return null;
    }
    
    public int pullTestItemsCount()
    {
    	int count = 0;
    	try {
    		connect();
    		PreparedStatement preparedStmt = conn.prepareStatement(queryPullTestItemsCount);
			preparedStmt.setInt(1, theOneTheOnlyTestID);
			ResultSet rs = preparedStmt.executeQuery();
			while (rs.next())
			{
				count = rs.getInt("Count");
			}
				return count;
		}
		catch (SQLException e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
    	return count;
    }
    
    /**
     * checks user against the database to see if it is an administrator 
     * @param username of the current user
     * @return the access role of the current user
     */
    public boolean isUserAccessAdmin(String username)
    {
    	String role = null;
    	try {
    		connect();
    		PreparedStatement preparedStmt = conn.prepareStatement(queryPullUserAccessRole);
			preparedStmt.setString(1, username);
			ResultSet rs = preparedStmt.executeQuery();
			while (rs.next())
			{
				role = rs.getString("role");
			}
				if (role.equals(adminAccessRole)) return true; else return false;
		}
		catch (SQLException e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
    	return false;
    }
}