package nsort.model;
/**
 * Item is an nsort.model component.  An Item is an 'item' that a nsort.test taker 
 * will compare to another item.
 * 
 * @author (Chris.Stultz, John.Loranger, Ryan.Reams, Josh.Eads) 
 * @version (4/21/2015)
 */
public class Item {
	
	private String value;
    private int wins;
    private int losses;
    private int ties;
	
	public Item() 
	{
		setValue("");
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
    /**
     * returns the wins total of the item. 
     * 
     * @return the wins total of the item.
     */
    public int getWins()
    {
        return wins;
    }

    /**
     * Set the wins of the item.
     * 
     * @param the wins of the item.
     */
    public void setWins(int wins)
    {
        this.wins = wins;
    }

    /**
     * returns the losses total of the item. 
     * 
     * @return the losses total of the item.
     */
    public int getLosses()
    {
        return losses;
    }

    /**
     * Set the losses of the item.
     * 
     * @param the losses of the item.
     */
    public void setLosses(int losses)
    {
        this.losses = losses;
    }

    /**
     * returns the ties total of the item. 
     * 
     * @return the ties total of the item.
     */
    public int getTies()
    {
        return ties;
    }

    /**
     * Set the ties of the item.
     * 
     * @param the ties of the item.
     */
    public void setTies(int ties)
    {
        this.ties = ties;
    }

    /**
     * Check if an Item is equal to its value
     */
    public Boolean equals(String value)
    {
    	if (this.value.equals(value))
    	{
    		return true;
    	}
    	else return false;
    }
    
}
